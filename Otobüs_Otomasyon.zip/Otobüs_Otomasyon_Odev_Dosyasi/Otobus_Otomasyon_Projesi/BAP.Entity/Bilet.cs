﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAP.Entity
{
    public class Bilet : BaseType
    {
        public Bilet()
        {
            this.Cinsiyet = false;
        }
        public int Adet { get; set; }
        public decimal ToplamFiyat { get; set; }
        public string YolcuAdSoyad { get; set; }
        public long YolcuTC { get; set; }
        public string YolcuTel { get; set; }
        public bool? Cinsiyet { get; set; }
        public int Koltuk { get; set; }
        public int Durum { get; set; }
        public int SeferId { get; set; }
    }
}
