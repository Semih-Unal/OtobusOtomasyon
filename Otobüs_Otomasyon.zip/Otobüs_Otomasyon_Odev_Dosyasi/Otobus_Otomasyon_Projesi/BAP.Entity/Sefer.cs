﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAP.Entity
{
    public class Sefer : BaseType
    {
        public Sefer()
        {
            this.Tarih = DateTime.Now;
        }
        public int Kalkis { get; set; }
        public int Varis { get; set; }
        public DateTime? Tarih { get; set; }
        public int SeferNo { get; set; }
        public decimal Fiyat { get; set; }
        public string Saat { get; set; }
        public int OtobusId { get; set; }
    }
}
