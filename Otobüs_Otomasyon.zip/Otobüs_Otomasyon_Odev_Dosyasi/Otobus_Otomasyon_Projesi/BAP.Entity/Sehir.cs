﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAP.Entity
{
   public class Sehir : BaseType
    {
        public string SehirAdi { get; set; }

        public override string ToString()
        {
            return this.SehirAdi;
        }
    }
}
