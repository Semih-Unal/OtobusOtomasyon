﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAP.Entity
{
    public class BaseType
    {
        public BaseType()
        {
            this.CreateDate = DateTime.Now;
        }
        public int Id { get; set; }
        public DateTime? CreateDate { get; set; }
    }
}
