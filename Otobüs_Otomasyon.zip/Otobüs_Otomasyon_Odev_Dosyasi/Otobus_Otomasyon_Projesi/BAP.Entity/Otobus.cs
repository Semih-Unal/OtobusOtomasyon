﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAP.Entity
{
    public class Otobus : BaseType
    {
        public string SoforAdSoyad { get; set; }
        public string Plaka { get; set; }
        public string Marka { get; set; }
        public int KoltukSayisi { get; set; }
        public string Resim { get; set; }
    }
}
