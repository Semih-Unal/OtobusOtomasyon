﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAP.UI.Forms
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }
        string guid;
        private void frmLogin_Load(object sender, EventArgs e)
        {
            guid = Guid.NewGuid().ToString().Replace(" ", "").Substring(0, 5);
            lblSecurity.Text = guid;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text.ToLower() == "cihan" && txtPassword.Text == "123456" && guid.ToLower() == txtCode.Text.ToLower())
            {
                MessageBox.Show("Hoşgeldiniz ...");
                Forms.frmYonetici frmAdmin = new frmYonetici();
                this.Hide();
                frmAdmin.Show();

            }
            else
            {
                MessageBox.Show("Bilgileri Kontrol Edip Tekrar Deneyiniz !!!");
            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Form1 frmAna = new Form1();
            this.Close();
            frmAna.Show();
        }
    }
}
