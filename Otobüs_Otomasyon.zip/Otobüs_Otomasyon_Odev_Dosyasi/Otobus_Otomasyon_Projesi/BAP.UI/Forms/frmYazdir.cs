﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//-------------------------
using BAP.Common;
using BAP.Entity;
using BAP.Dal;
using System.Collections;

namespace BAP.UI.Forms
{
    public partial class frmYazdir : Form
    {
        seferDal sfrDal = new seferDal();
        sehirDal cityDal = new sehirDal();
        otobusDal busDal = new otobusDal();
        public frmYazdir(Bilet blt)
        {
            InitializeComponent();
            lblAdSoyad.Text = blt.YolcuAdSoyad;
            lblTcNo.Text = blt.YolcuTC.ToString();
            lblKoltukNo.Text = blt.Koltuk.ToString();

            Sefer sfr = sfrDal.ListOfSeferbyId(blt.SeferId).TransactionResult;

            lblNereden.Text = cityDal.SelectSehirbyId(sfr.Kalkis).TransactionResult.SehirAdi;
            lblNereye.Text = cityDal.SelectSehirbyId(sfr.Varis).TransactionResult.SehirAdi;
            lblTarih.Text = Convert.ToDateTime(sfr.Tarih).ToLongDateString();
            lblSeferNo.Text = sfr.SeferNo.ToString();
            lblSaat.Text = sfr.Saat;
            lblPlaka.Text = busDal.ListOfOtobusById(sfr.OtobusId).TransactionResult.Plaka;
            lblTutar.Text = string.Format("{0:C2}", sfr.Fiyat.ToString());
        }

        private void btnYazdir_Click(object sender, EventArgs e)
        {
            PrintDialog print = new PrintDialog();
            if (print.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
            
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bm = new Bitmap(this.panelBilet.Width, this.panelBilet.Height);
            panelBilet.DrawToBitmap(bm, new Rectangle(0,0, this.panelBilet.Width, this.panelBilet.Height));
            e.Graphics.DrawImage(bm,0,0);
        }

        private void frmYazdir_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 frmAna = new Form1();
            frmAna.Show();
        }
    }
}
