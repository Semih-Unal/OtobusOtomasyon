﻿namespace BAP.UI.Forms
{
    partial class frmYonetici
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmYonetici));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.mtxtSaat = new System.Windows.Forms.MaskedTextBox();
            this.txtSeferNo = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnSeferUpdate = new System.Windows.Forms.Button();
            this.btnSeferDelete = new System.Windows.Forms.Button();
            this.btnSeferClear = new System.Windows.Forms.Button();
            this.btnSeferAdd = new System.Windows.Forms.Button();
            this.nUdFiyat = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dTpTarih = new System.Windows.Forms.DateTimePicker();
            this.cbOtobus = new System.Windows.Forms.ComboBox();
            this.cbVaris = new System.Windows.Forms.ComboBox();
            this.cbKalkis = new System.Windows.Forms.ComboBox();
            this.dGwSeferler = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dGwOtobusler = new System.Windows.Forms.DataGridView();
            this.btnBusUpdate = new System.Windows.Forms.Button();
            this.btnBusDelete = new System.Windows.Forms.Button();
            this.btnBusClear = new System.Windows.Forms.Button();
            this.btnBusAdd = new System.Windows.Forms.Button();
            this.btnResimSec = new System.Windows.Forms.Button();
            this.pbResim = new System.Windows.Forms.PictureBox();
            this.nUdKoltukSayisi = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMarka = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPlaka = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSoforAdSoyad = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHome = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nUdFiyat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGwSeferler)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwOtobusler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbResim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUdKoltukSayisi)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tabControl1.Location = new System.Drawing.Point(0, 48);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(731, 450);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage1.Controls.Add(this.mtxtSaat);
            this.tabPage1.Controls.Add(this.txtSeferNo);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.btnSeferUpdate);
            this.tabPage1.Controls.Add(this.btnSeferDelete);
            this.tabPage1.Controls.Add(this.btnSeferClear);
            this.tabPage1.Controls.Add(this.btnSeferAdd);
            this.tabPage1.Controls.Add(this.nUdFiyat);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.dTpTarih);
            this.tabPage1.Controls.Add(this.cbOtobus);
            this.tabPage1.Controls.Add(this.cbVaris);
            this.tabPage1.Controls.Add(this.cbKalkis);
            this.tabPage1.Controls.Add(this.dGwSeferler);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(723, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Seferler";
            // 
            // mtxtSaat
            // 
            this.mtxtSaat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtSaat.Location = new System.Drawing.Point(463, 57);
            this.mtxtSaat.Mask = "00:00";
            this.mtxtSaat.Name = "mtxtSaat";
            this.mtxtSaat.Size = new System.Drawing.Size(72, 26);
            this.mtxtSaat.TabIndex = 43;
            this.mtxtSaat.ValidatingType = typeof(System.DateTime);
            // 
            // txtSeferNo
            // 
            this.txtSeferNo.Enabled = false;
            this.txtSeferNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSeferNo.Location = new System.Drawing.Point(463, 99);
            this.txtSeferNo.Name = "txtSeferNo";
            this.txtSeferNo.Size = new System.Drawing.Size(116, 26);
            this.txtSeferNo.TabIndex = 42;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(358, 102);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 20);
            this.label14.TabIndex = 41;
            this.label14.Text = "Sefer No :";
            // 
            // btnSeferUpdate
            // 
            this.btnSeferUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSeferUpdate.Location = new System.Drawing.Point(432, 161);
            this.btnSeferUpdate.Name = "btnSeferUpdate";
            this.btnSeferUpdate.Size = new System.Drawing.Size(87, 31);
            this.btnSeferUpdate.TabIndex = 40;
            this.btnSeferUpdate.Text = "Güncelle";
            this.btnSeferUpdate.UseVisualStyleBackColor = true;
            this.btnSeferUpdate.Click += new System.EventHandler(this.btnSeferUpdate_Click);
            // 
            // btnSeferDelete
            // 
            this.btnSeferDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSeferDelete.Location = new System.Drawing.Point(525, 161);
            this.btnSeferDelete.Name = "btnSeferDelete";
            this.btnSeferDelete.Size = new System.Drawing.Size(79, 31);
            this.btnSeferDelete.TabIndex = 39;
            this.btnSeferDelete.Text = "Sil";
            this.btnSeferDelete.UseVisualStyleBackColor = true;
            this.btnSeferDelete.Click += new System.EventHandler(this.btnSeferDelete_Click);
            // 
            // btnSeferClear
            // 
            this.btnSeferClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSeferClear.Location = new System.Drawing.Point(265, 161);
            this.btnSeferClear.Name = "btnSeferClear";
            this.btnSeferClear.Size = new System.Drawing.Size(78, 31);
            this.btnSeferClear.TabIndex = 37;
            this.btnSeferClear.Text = "Temizle";
            this.btnSeferClear.UseVisualStyleBackColor = true;
            this.btnSeferClear.Click += new System.EventHandler(this.btnSeferClear_Click);
            // 
            // btnSeferAdd
            // 
            this.btnSeferAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSeferAdd.Location = new System.Drawing.Point(349, 161);
            this.btnSeferAdd.Name = "btnSeferAdd";
            this.btnSeferAdd.Size = new System.Drawing.Size(77, 31);
            this.btnSeferAdd.TabIndex = 38;
            this.btnSeferAdd.Text = "Ekle";
            this.btnSeferAdd.UseVisualStyleBackColor = true;
            this.btnSeferAdd.Click += new System.EventHandler(this.btnSeferAdd_Click);
            // 
            // nUdFiyat
            // 
            this.nUdFiyat.DecimalPlaces = 2;
            this.nUdFiyat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nUdFiyat.Increment = new decimal(new int[] {
            50,
            0,
            0,
            131072});
            this.nUdFiyat.Location = new System.Drawing.Point(463, 21);
            this.nUdFiyat.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.nUdFiyat.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nUdFiyat.Name = "nUdFiyat";
            this.nUdFiyat.Size = new System.Drawing.Size(72, 26);
            this.nUdFiyat.TabIndex = 35;
            this.nUdFiyat.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(552, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 20);
            this.label10.TabIndex = 33;
            this.label10.Text = "TL";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(358, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 20);
            this.label12.TabIndex = 34;
            this.label12.Text = "Kalkış Saati :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(358, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 20);
            this.label11.TabIndex = 34;
            this.label11.Text = "Fiyat :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(8, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 20);
            this.label9.TabIndex = 32;
            this.label9.Text = "Tarih :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(8, 118);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 20);
            this.label13.TabIndex = 32;
            this.label13.Text = "Otobüs :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(8, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 20);
            this.label8.TabIndex = 32;
            this.label8.Text = "Varış Noktası :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(8, 52);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 20);
            this.label7.TabIndex = 32;
            this.label7.Text = "Kalkış Noktası :";
            // 
            // dTpTarih
            // 
            this.dTpTarih.Font = new System.Drawing.Font("MS Office Symbol Regular", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dTpTarih.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTpTarih.Location = new System.Drawing.Point(149, 17);
            this.dTpTarih.Name = "dTpTarih";
            this.dTpTarih.Size = new System.Drawing.Size(189, 26);
            this.dTpTarih.TabIndex = 31;
            // 
            // cbOtobus
            // 
            this.cbOtobus.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbOtobus.FormattingEnabled = true;
            this.cbOtobus.Location = new System.Drawing.Point(149, 115);
            this.cbOtobus.Name = "cbOtobus";
            this.cbOtobus.Size = new System.Drawing.Size(189, 26);
            this.cbOtobus.TabIndex = 26;
            this.cbOtobus.Text = "- Seçiniz -";
            // 
            // cbVaris
            // 
            this.cbVaris.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbVaris.FormattingEnabled = true;
            this.cbVaris.Location = new System.Drawing.Point(149, 83);
            this.cbVaris.Name = "cbVaris";
            this.cbVaris.Size = new System.Drawing.Size(189, 26);
            this.cbVaris.TabIndex = 26;
            this.cbVaris.Text = "- Seçiniz -";
            // 
            // cbKalkis
            // 
            this.cbKalkis.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbKalkis.FormattingEnabled = true;
            this.cbKalkis.Location = new System.Drawing.Point(149, 49);
            this.cbKalkis.Name = "cbKalkis";
            this.cbKalkis.Size = new System.Drawing.Size(189, 26);
            this.cbKalkis.TabIndex = 27;
            this.cbKalkis.Text = "- Seçiniz -";
            this.cbKalkis.SelectionChangeCommitted += new System.EventHandler(this.cbKalkis_SelectionChangeCommitted);
            // 
            // dGwSeferler
            // 
            this.dGwSeferler.AllowUserToAddRows = false;
            this.dGwSeferler.AllowUserToOrderColumns = true;
            this.dGwSeferler.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGwSeferler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGwSeferler.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dGwSeferler.Location = new System.Drawing.Point(3, 216);
            this.dGwSeferler.MultiSelect = false;
            this.dGwSeferler.Name = "dGwSeferler";
            this.dGwSeferler.ReadOnly = true;
            this.dGwSeferler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwSeferler.Size = new System.Drawing.Size(717, 205);
            this.dGwSeferler.TabIndex = 25;
            this.dGwSeferler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGwSeferler_CellClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tabPage2.Controls.Add(this.dGwOtobusler);
            this.tabPage2.Controls.Add(this.btnBusUpdate);
            this.tabPage2.Controls.Add(this.btnBusDelete);
            this.tabPage2.Controls.Add(this.btnBusClear);
            this.tabPage2.Controls.Add(this.btnBusAdd);
            this.tabPage2.Controls.Add(this.btnResimSec);
            this.tabPage2.Controls.Add(this.pbResim);
            this.tabPage2.Controls.Add(this.nUdKoltukSayisi);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.txtPath);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtMarka);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.txtPlaka);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.txtSoforAdSoyad);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(723, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Otobüsler";
            // 
            // dGwOtobusler
            // 
            this.dGwOtobusler.AllowUserToAddRows = false;
            this.dGwOtobusler.AllowUserToOrderColumns = true;
            this.dGwOtobusler.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGwOtobusler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGwOtobusler.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dGwOtobusler.Location = new System.Drawing.Point(3, 238);
            this.dGwOtobusler.MultiSelect = false;
            this.dGwOtobusler.Name = "dGwOtobusler";
            this.dGwOtobusler.ReadOnly = true;
            this.dGwOtobusler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwOtobusler.Size = new System.Drawing.Size(717, 183);
            this.dGwOtobusler.TabIndex = 24;
            this.dGwOtobusler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGwVeriler_CellClick);
            // 
            // btnBusUpdate
            // 
            this.btnBusUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBusUpdate.Location = new System.Drawing.Point(438, 187);
            this.btnBusUpdate.Name = "btnBusUpdate";
            this.btnBusUpdate.Size = new System.Drawing.Size(87, 31);
            this.btnBusUpdate.TabIndex = 23;
            this.btnBusUpdate.Text = "Güncelle";
            this.btnBusUpdate.UseVisualStyleBackColor = true;
            this.btnBusUpdate.Click += new System.EventHandler(this.btnBusUpdate_Click);
            // 
            // btnBusDelete
            // 
            this.btnBusDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBusDelete.Location = new System.Drawing.Point(531, 187);
            this.btnBusDelete.Name = "btnBusDelete";
            this.btnBusDelete.Size = new System.Drawing.Size(79, 31);
            this.btnBusDelete.TabIndex = 22;
            this.btnBusDelete.Text = "Sil";
            this.btnBusDelete.UseVisualStyleBackColor = true;
            this.btnBusDelete.Click += new System.EventHandler(this.btnBusDelete_Click);
            // 
            // btnBusClear
            // 
            this.btnBusClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBusClear.Location = new System.Drawing.Point(271, 187);
            this.btnBusClear.Name = "btnBusClear";
            this.btnBusClear.Size = new System.Drawing.Size(78, 31);
            this.btnBusClear.TabIndex = 21;
            this.btnBusClear.Text = "Temizle";
            this.btnBusClear.UseVisualStyleBackColor = true;
            this.btnBusClear.Click += new System.EventHandler(this.btnBusClear_Click);
            // 
            // btnBusAdd
            // 
            this.btnBusAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBusAdd.Location = new System.Drawing.Point(355, 187);
            this.btnBusAdd.Name = "btnBusAdd";
            this.btnBusAdd.Size = new System.Drawing.Size(77, 31);
            this.btnBusAdd.TabIndex = 21;
            this.btnBusAdd.Text = "Ekle";
            this.btnBusAdd.UseVisualStyleBackColor = true;
            this.btnBusAdd.Click += new System.EventHandler(this.btnBusAdd_Click);
            // 
            // btnResimSec
            // 
            this.btnResimSec.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResimSec.Location = new System.Drawing.Point(571, 141);
            this.btnResimSec.Name = "btnResimSec";
            this.btnResimSec.Size = new System.Drawing.Size(37, 26);
            this.btnResimSec.TabIndex = 20;
            this.btnResimSec.Text = "---";
            this.btnResimSec.UseVisualStyleBackColor = true;
            this.btnResimSec.Click += new System.EventHandler(this.btnResimSec_Click);
            // 
            // pbResim
            // 
            this.pbResim.BackColor = System.Drawing.Color.White;
            this.pbResim.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbResim.Location = new System.Drawing.Point(30, 12);
            this.pbResim.Name = "pbResim";
            this.pbResim.Size = new System.Drawing.Size(174, 151);
            this.pbResim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbResim.TabIndex = 19;
            this.pbResim.TabStop = false;
            // 
            // nUdKoltukSayisi
            // 
            this.nUdKoltukSayisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nUdKoltukSayisi.Location = new System.Drawing.Point(365, 109);
            this.nUdKoltukSayisi.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nUdKoltukSayisi.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nUdKoltukSayisi.Name = "nUdKoltukSayisi";
            this.nUdKoltukSayisi.Size = new System.Drawing.Size(200, 26);
            this.nUdKoltukSayisi.TabIndex = 18;
            this.nUdKoltukSayisi.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(567, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Adet";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(224, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 20);
            this.label4.TabIndex = 11;
            this.label4.Text = "Koltuk Sayısı :";
            // 
            // txtPath
            // 
            this.txtPath.Enabled = false;
            this.txtPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtPath.Location = new System.Drawing.Point(365, 141);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(200, 26);
            this.txtPath.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(224, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 20);
            this.label6.TabIndex = 13;
            this.label6.Text = "Path :";
            // 
            // txtMarka
            // 
            this.txtMarka.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtMarka.Location = new System.Drawing.Point(365, 76);
            this.txtMarka.Name = "txtMarka";
            this.txtMarka.Size = new System.Drawing.Size(245, 26);
            this.txtMarka.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(224, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Marka :";
            // 
            // txtPlaka
            // 
            this.txtPlaka.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtPlaka.Location = new System.Drawing.Point(365, 44);
            this.txtPlaka.Name = "txtPlaka";
            this.txtPlaka.Size = new System.Drawing.Size(245, 26);
            this.txtPlaka.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(224, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Plaka :";
            // 
            // txtSoforAdSoyad
            // 
            this.txtSoforAdSoyad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSoforAdSoyad.Location = new System.Drawing.Point(365, 12);
            this.txtSoforAdSoyad.Name = "txtSoforAdSoyad";
            this.txtSoforAdSoyad.Size = new System.Drawing.Size(245, 26);
            this.txtSoforAdSoyad.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(224, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Şoför Adı Soyadı :";
            // 
            // btnHome
            // 
            this.btnHome.BackgroundImage = global::BAP.UI.Properties.Resources.home;
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Location = new System.Drawing.Point(702, -1);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(29, 29);
            this.btnHome.TabIndex = 9;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // frmYonetici
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 498);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmYonetici";
            this.Text = "Yöneti Paneli";
            this.Load += new System.EventHandler(this.frmYonetici_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nUdFiyat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGwSeferler)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwOtobusler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbResim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUdKoltukSayisi)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnBusUpdate;
        private System.Windows.Forms.Button btnBusDelete;
        private System.Windows.Forms.Button btnBusAdd;
        private System.Windows.Forms.Button btnResimSec;
        private System.Windows.Forms.PictureBox pbResim;
        private System.Windows.Forms.NumericUpDown nUdKoltukSayisi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMarka;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPlaka;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSoforAdSoyad;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dGwOtobusler;
        private System.Windows.Forms.Button btnBusClear;
        private System.Windows.Forms.DataGridView dGwSeferler;
        private System.Windows.Forms.Button btnSeferUpdate;
        private System.Windows.Forms.Button btnSeferDelete;
        private System.Windows.Forms.Button btnSeferClear;
        private System.Windows.Forms.Button btnSeferAdd;
        private System.Windows.Forms.NumericUpDown nUdFiyat;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dTpTarih;
        private System.Windows.Forms.ComboBox cbOtobus;
        private System.Windows.Forms.ComboBox cbVaris;
        private System.Windows.Forms.ComboBox cbKalkis;
        private System.Windows.Forms.TextBox txtSeferNo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox mtxtSaat;
        private System.Windows.Forms.Button btnHome;
    }
}