﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//---------------------------
using BAP.Common;
using BAP.Entity;
using BAP.Dal;
using System.IO;

namespace BAP.UI.Forms
{
    public partial class frmYonetici : Form
    {
        public frmYonetici()
        {
            InitializeComponent();
        }
        otobusDal busDal = new otobusDal();
        int bussecilenID;

        seferDal sDal = new seferDal();
        sehirDal cityDal = new sehirDal();
        int sfrsecilenID;
        private void frmYonetici_Load(object sender, EventArgs e)
        {
            BusFill();
            SeferFill();
            KalkisDoldur();
            OtobusDoldur();
        }

        private void OtobusDoldur()
        {
            var busList = busDal.ListOfOtobus();

            cbOtobus.DataSource = busList.TransactionResult;
            cbOtobus.DisplayMember = "Plaka";
            cbOtobus.ValueMember = "OtobusId";
        }

        private void KalkisDoldur()
        {
            var citiesList = cityDal.ListOfSehir();

            cbKalkis.DataSource = citiesList.TransactionResult;
        }

        private void BusFill()
        {
            var list = busDal.ListOfOtobus();
            dGwOtobusler.DataSource = list.TransactionResult;
        }

        private void SeferFill()
        {
            var list = sDal.ListOfSefer();
            dGwSeferler.DataSource = list.TransactionResult;
        }


        #region Otobüsler
        // Resim Seç
        string path;
        private void btnResimSec_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                path = ofd.FileName;

                pbResim.Image = Image.FromFile(path);
                txtPath.Text = path;
            }
        }
        // Ekle
        private void btnBusAdd_Click(object sender, EventArgs e)
        {
            if (txtSoforAdSoyad.Text == "" || txtPlaka.Text == "" || txtMarka.Text == "" || txtPath.Text == "" || nUdKoltukSayisi.Value == 1)
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz !!!");
                return;
            }


            string pic = @"..\..\Images\bus_" + Guid.NewGuid().ToString().Replace(" ", "-").Substring(0, 4) + Path.GetExtension(path);

            Image img = Image.FromFile(path);

            img.Save(pic);

            Otobus bus = new Otobus()
            {
                SoforAdSoyad = txtSoforAdSoyad.Text,
                Plaka = txtPlaka.Text,
                Marka = txtMarka.Text,
                KoltukSayisi = Convert.ToInt32(nUdKoltukSayisi.Value),
                Resim = pic,
                CreateDate = DateTime.Now
            };

            var result = busDal.Save(bus);
            if (result.IsSucceeded == true)
                MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
            else
                MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");
            BusFill();
            Temizle();
        }
        // Güncelle
        private void btnBusUpdate_Click(object sender, EventArgs e)
        {
            if (bussecilenID == 0)
            {
                MessageBox.Show("Lütfen güncellemek istediğiniz otobüsü seçiniz !!! ");
                return;
            }
            if (txtSoforAdSoyad.Text == "" || txtPlaka.Text == "" || txtMarka.Text == "" || txtPath.Text == "" || nUdKoltukSayisi.Value == 1)
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz !!!");
                return;
            }

            string pic = txtPath.Text;

            if (path != null && path != "")
            {
                pic = @"..\..\Images\bus_" + Guid.NewGuid().ToString().Replace(" ", "-").Substring(0, 4) + Path.GetExtension(path);

                Image img = Image.FromFile(path);

                img.Save(pic);
            }

            Otobus bus = new Otobus()
            {
                Id = bussecilenID,
                SoforAdSoyad = txtSoforAdSoyad.Text,
                Plaka = txtPlaka.Text,
                Marka = txtMarka.Text,
                KoltukSayisi = Convert.ToInt32(nUdKoltukSayisi.Value),
                Resim = pic,
                CreateDate = DateTime.Now
            };

            var result = busDal.Update(bus);

            if (result.IsSucceeded == true)
                MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
            else
                MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");
            BusFill();
            Temizle();
        }
        // Sil
        private void btnBusDelete_Click(object sender, EventArgs e)
        {
            if (bussecilenID == 0)
            {
                MessageBox.Show("Lütfen silmek istediğiniz otobüsü seçiniz !!! ");
                return;
            }
            var result = busDal.Delete(bussecilenID);

            if (result.IsSucceeded == true)
                MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
            else
                MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");

            BusFill();
            Temizle();
        }
        // Seç
        private void dGwVeriler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            bussecilenID = (int)dGwOtobusler.CurrentRow.Cells[5].Value;

            var bus = busDal.ListOfOtobusById(bussecilenID).TransactionResult;

            txtSoforAdSoyad.Text = bus.SoforAdSoyad;
            txtMarka.Text = bus.Marka;
            txtPlaka.Text = bus.Plaka;
            txtPath.Text = bus.Resim;
            if (bus.Resim != "")
                pbResim.Image = Image.FromFile(bus.Resim);
            else
                pbResim.Image = null;
            nUdKoltukSayisi.Value = bus.KoltukSayisi;
        }

        private void btnBusClear_Click(object sender, EventArgs e)
        {
            Temizle();
        }
        #endregion

        #region Sefer

        private void cbKalkis_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Sehir secilenItem = cbKalkis.SelectedItem as Sehir;

            VarisDoldur(secilenItem.Id);
        }

        private void VarisDoldur(int secilenId)
        {
            var citiesList = cityDal.ListOfSehirbyId(secilenId);

            cbVaris.DataSource = citiesList.TransactionResult;
        }

        Random rnd = new Random();
        private void btnSeferAdd_Click(object sender, EventArgs e)
        {
            Sehir secilenKalkis = cbKalkis.SelectedItem as Sehir;
            Sehir secilenVaris = cbVaris.SelectedItem as Sehir;
            Otobus secilenOto = cbOtobus.SelectedItem as Otobus;

            if (mtxtSaat.Text == null || mtxtSaat.Text == "" || nUdFiyat.Value == 10 || secilenKalkis == null || secilenVaris == null || secilenOto == null)
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz !!!");
                return;
            }
            Sefer s = new Sefer()
            {
                Kalkis = secilenKalkis.Id,
                Varis = secilenVaris.Id,
                Fiyat = nUdFiyat.Value,
                Saat = mtxtSaat.Text,
                Tarih = Convert.ToDateTime(dTpTarih.Value),
                SeferNo = rnd.Next(0, 1000000),
                OtobusId = secilenOto.Id,
                CreateDate = DateTime.Now
            };

            var result = sDal.Save(s);
            if (result.IsSucceeded == true)
                MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
            else
                MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");
            SeferFill();
            Temizle();
        }

        private void btnSeferUpdate_Click(object sender, EventArgs e)
        {
            if (sfrsecilenID == 0)
            {
                MessageBox.Show("Lütfen güncellemek istediğiniz seferi seçiniz !!! ");
                return;
            }
            Sehir secilenKalkis = cbKalkis.SelectedItem as Sehir;
            Sehir secilenVaris = cbVaris.SelectedItem as Sehir;
            Otobus secilenOto = cbOtobus.SelectedItem as Otobus;

            if (mtxtSaat.Text == null || mtxtSaat.Text == "" || nUdFiyat.Value == 10 || secilenKalkis == null || secilenVaris == null || secilenOto == null)
            {
                MessageBox.Show("Lütfen Tüm Alanları Doldurunuz !!!");
                return;
            }
            Sefer s = new Sefer()
            {
                Id = sfrsecilenID,
                Kalkis = secilenKalkis.Id,
                Varis = secilenVaris.Id,
                Fiyat = nUdFiyat.Value,
                Saat = mtxtSaat.Text,
                Tarih = Convert.ToDateTime(dTpTarih.Value),
                SeferNo = Convert.ToInt32(txtSeferNo.Text),
                OtobusId = secilenOto.Id,
                CreateDate = DateTime.Now
            };

            var result = sDal.Update(s);
            if (result.IsSucceeded == true)
                MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
            else
                MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");
            SeferFill();
            Temizle();
        }

        private void btnSeferDelete_Click(object sender, EventArgs e)
        {
            if (sfrsecilenID == 0)
            {
                MessageBox.Show("Lütfen silmek istediğiniz seferi seçiniz !!! ");
                return;
            }

            var result = sDal.Delete(sfrsecilenID);
            if (result.IsSucceeded == true)
                MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
            else
                MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");
            SeferFill();
            Temizle();
        }

        private void btnSeferClear_Click(object sender, EventArgs e)
        {
            Temizle();
        }

        private void dGwSeferler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            sfrsecilenID = (int)dGwSeferler.CurrentRow.Cells[7].Value;

            var secilenSefer = sDal.ListOfSeferbyId(sfrsecilenID).TransactionResult;

            dTpTarih.Value = Convert.ToDateTime(secilenSefer.Tarih);
            SeciliCbSehirItem(cbKalkis,secilenSefer.Kalkis);
            SeciliCbSehirItem(cbVaris, secilenSefer.Varis);
            SeciliCbBusItem(cbOtobus, secilenSefer.OtobusId);
            nUdFiyat.Value = Convert.ToDecimal(secilenSefer.Fiyat);
            mtxtSaat.Text = secilenSefer.Saat;
            txtSeferNo.Text = secilenSefer.SeferNo.ToString();

        }

        private void SeciliCbSehirItem(ComboBox cb, int selectId)
        {
            cb.DataSource = null;
            cb.Items.Clear();
            foreach (Sehir shr in cityDal.ListOfSehir().TransactionResult)
            {
                cb.Items.Add(shr);

                if (shr.Id == selectId)
                {
                    cb.SelectedItem = shr;
                }
            }
        }
        private void SeciliCbBusItem(ComboBox cb, int selectId)
        {
            cb.DataSource = null;
            cb.Items.Clear();
            foreach (Otobus bus in busDal.ListOfOtobus().TransactionResult)
            {
                cb.Items.Add(bus);

                if (bus.Id == selectId)
                {
                    cb.SelectedItem = bus;
                    cb.DisplayMember = "Plaka";
                }
            }
        }
        #endregion

        private void Temizle()
        {
            txtMarka.Clear();
            txtPath.Clear();
            txtPlaka.Clear();
            txtSoforAdSoyad.Clear();
            nUdKoltukSayisi.Value = 1;
            pbResim.Image = null;

            dTpTarih.Value = DateTime.Now;
            cbKalkis.Text = "- Seçiniz -";
            cbVaris.Text = "- Seçiniz -";
            cbVaris.DataSource = null;
            cbOtobus.Text = "- Seçiniz -";
            nUdFiyat.Value = 10;
            mtxtSaat.Clear();

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Temizle();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            Form1 frmAna = new Form1();
            this.Close();
            frmAna.Show();
        }
    }
}
