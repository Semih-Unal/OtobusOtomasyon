﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//-------------------------
using BAP.Common;
using BAP.Entity;
using BAP.Dal;
using System.Collections;

namespace BAP.UI.Forms
{
    public partial class frmBilet : Form
    {
        Sefer sfr = new Sefer();
        otobusDal busDal = new otobusDal();
        sehirDal cityDal = new sehirDal();
        biletDal bltDal = new biletDal();
        Otobus seciliOtobus = new Otobus();
        List<Bilet> kesilenBiletler = new List<Bilet>();
        public frmBilet(Sefer gelenSfr)
        {
            InitializeComponent();
            txtSefer.Text = cityDal.SelectSehirbyId(gelenSfr.Kalkis).TransactionResult + "-" + cityDal.SelectSehirbyId(gelenSfr.Varis).TransactionResult ;
            txtFiyat.Text = gelenSfr.Fiyat.ToString();
            sfr = gelenSfr;

            seciliOtobus = busDal.ListOfOtobusById(gelenSfr.OtobusId).TransactionResult;
            txtPlaka.Text = seciliOtobus.Plaka;

            kesilenBiletler = bltDal.ListOfBiletbySeferId(sfr.Id).TransactionResult;
        }

        private void frmBilet_Load(object sender, EventArgs e)
        {
            KoltuklariGetir();

        }

        private void KoltuklariGetir()
        {
            int mod4 = seciliOtobus.KoltukSayisi % 4;
            int mod3 = seciliOtobus.KoltukSayisi % 3;
            int kalan = 1;

            Panel pnl = new Panel();
            pnl.Width = fLpKoltuklar.Width;
            pnl.Height = 20;
            for (int i = 4; i > 0; i--)
            {

                if (mod4 == 0)
                {
                    if (i == 2)
                    {
                        fLpKoltuklar.Controls.Add(pnl);
                    }

                    kalan = seciliOtobus.KoltukSayisi / 4;
                }
                if (mod3 == 0)
                {
                    if (i == 2)
                    {
                        fLpKoltuklar.Controls.Add(pnl);
                        Panel pnl2 = new Panel();
                        pnl2.Width = fLpKoltuklar.Width;
                        pnl2.Height = (fLpKoltuklar.Width / 10) - 7;
                        fLpKoltuklar.Controls.Add(pnl2);
                    }
                    kalan = seciliOtobus.KoltukSayisi / 4;
                }
                for (int j = i; j <= 40; j=j+4)
                {
                    Button btn = new Button();
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.FlatAppearance.BorderSize = 0;
                    btn.BackgroundImage = ResourceKoltuk.free_seat;
                    btn.BackgroundImageLayout = ImageLayout.Stretch;
                    btn.Width = (fLpKoltuklar.Width / 10) - 14;
                    btn.Height = (fLpKoltuklar.Width / 10) - 14;

                    btn.ForeColor = Color.Black;
                    btn.Tag = j;
                    btn.Text = j.ToString();
                    foreach (Bilet blt in kesilenBiletler)
                    {
                        if (blt.Koltuk == j)
                        {
                            if (blt.Durum == 1)
                            {
                                if (blt.Cinsiyet == true)
                                {
                                    btn.BackgroundImage = ResourceKoltuk.red_man;
                                }
                                else
                                {
                                    btn.BackgroundImage = ResourceKoltuk.red_woman;
                                }
                                btn.ForeColor = Color.White;
                                btn.Enabled = false;
                            }
                            else if (blt.Durum == 2)
                            {
                                if (blt.Cinsiyet == true)
                                {
                                    btn.BackgroundImage = ResourceKoltuk.yellow_man;

                                }
                                else
                                {
                                    btn.BackgroundImage = ResourceKoltuk.yellow_woman;
                                }
                                btn.ForeColor = Color.White;
                            }
                            else
                            {
                                btn.BackColor = default(Color);
                            }
                        }
                    }
                    if (i != 2 || mod3 != 0)
                    {
                        fLpKoltuklar.Controls.Add(btn);
                    }

                    btn.Click += Btn_Click;
                }
            }
        }
        int secilenBiletID = 0;
        private void Btn_Click(object sender, EventArgs e)
        {
            Button tiklananBtn = sender as Button;
            txtKoltuk.Text = tiklananBtn.Tag.ToString();
            bool rezerve = false;
            var seciliBiletler = bltDal.ListOfBiletbySeferId(sfr.Id).TransactionResult;
            foreach (Bilet bilet in seciliBiletler)
            {
                if (bilet.Koltuk == (int)tiklananBtn.Tag && bilet.Durum == 2)
                {
                    txtAdSoyad.Text = bilet.YolcuAdSoyad;
                    mtxtTC.Text = bilet.YolcuTC.ToString();
                    mtxtTel.Text = bilet.YolcuTel;
                    secilenBiletID = bilet.Id;
                    if (bilet.Cinsiyet == true)
                    {
                        rbMan.Checked = true;
                    }
                    else
                    {
                        rbWoman.Checked = true;
                    }
                    rezerve = true;
                }
            }
                

            if (rezerve == true)
            {
                btnRezerve.Enabled = false;
                txtDurum.Text = "Rezerveli";
            }
            else
            {
                txtAdSoyad.Clear();
                mtxtTC.Clear();
                mtxtTel.Clear();
                secilenBiletID = 0;
                btnRezerve.Enabled = true;
                txtDurum.Text = "Boş";
            }
        }

        private void btnSatınAl_Click(object sender, EventArgs e)
        {
            if (txtKoltuk.Text == "" || txtAdSoyad.Text == "" || mtxtTC.Text == "" || mtxtTel.Text == "")
            {
                MessageBox.Show("Lütfen tüm Alanları Doldurunuz !!!");
                return;
            }
            bool gender = rbMan.Checked ? true : false;
            bool sonuc = false;
            if (txtDurum.Text == "Rezerveli")
            {
                Bilet blt = new Bilet()
                {
                    Id= secilenBiletID,
                    Adet = 1,
                    ToplamFiyat = Convert.ToDecimal(txtFiyat.Text),
                    Cinsiyet = gender,
                    Koltuk = Convert.ToInt32(txtKoltuk.Text),
                    YolcuAdSoyad = txtAdSoyad.Text,
                    YolcuTC = Convert.ToInt64(mtxtTC.Text),
                    YolcuTel = mtxtTel.Text,
                    Durum = 1,
                    SeferId = Convert.ToInt32(sfr.Id),
                    CreateDate = DateTime.Now
                };

                var result = bltDal.Update(blt);
                sonuc = result.IsSucceeded;
                if (result.IsSucceeded == true)
                    MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
                else
                    MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");
            }
            else
            {
                Bilet blt = new Bilet()
                {
                    Adet = 1,
                    ToplamFiyat = Convert.ToDecimal(txtFiyat.Text),
                    Cinsiyet = gender,
                    Koltuk = Convert.ToInt32(txtKoltuk.Text),
                    YolcuAdSoyad = txtAdSoyad.Text,
                    YolcuTC = Convert.ToInt64(mtxtTC.Text),
                    YolcuTel = mtxtTel.Text,
                    Durum = 1,
                    SeferId = Convert.ToInt32(sfr.Id),
                    CreateDate = DateTime.Now
                };

                var result = bltDal.Save(blt);
                sonuc = result.IsSucceeded;
                if (result.IsSucceeded == true)
                    MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
                else
                    MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");
            }
            if (sonuc==true)
            {
                Bilet yazdirilacakBilet = new Bilet()
                {
                    Koltuk = Convert.ToInt32(txtKoltuk.Text),
                    YolcuAdSoyad = txtAdSoyad.Text,
                    YolcuTC = Convert.ToInt64(mtxtTC.Text),
                    SeferId = Convert.ToInt32(sfr.Id)
                };
                frmYazdir yazdir = new frmYazdir(yazdirilacakBilet);
                this.Hide();
                yazdir.Show();


                Temizle();
            }
        }

        private void btnRezerve_Click(object sender, EventArgs e)
        {
            bool gender = rbMan.Checked ? true : false;
            Bilet blt = new Bilet()
            {
                Adet = 1,
                ToplamFiyat = Convert.ToDecimal(txtFiyat.Text),
                Cinsiyet = gender,
                Koltuk = Convert.ToInt32(txtKoltuk.Text),
                YolcuAdSoyad = txtAdSoyad.Text,
                YolcuTC = Convert.ToInt64(mtxtTC.Text),
                YolcuTel = mtxtTel.Text,
                Durum = 2,
                SeferId = Convert.ToInt32(sfr.Id),
                CreateDate = DateTime.Now
            };
            var result = bltDal.Save(blt);
            if (result.IsSucceeded == true)
                MessageBox.Show("İşleminiz başarılı şekilde gerçekleşmiştir ....");
            else
                MessageBox.Show("Hatayla karşılaşıldı, tekrar deneyiniz.");

            Temizle();


            Form1 frmAna = new Form1();
            this.Close();
            frmAna.Show();
        }

        private void btnVazgec_Click(object sender, EventArgs e)
        {
            Form1 frmAna = new Form1();
            this.Close();
            frmAna.Show();
        }

        private void Temizle()
        {
            txtKoltuk.Clear();
            txtDurum.Clear();
            txtAdSoyad.Clear();
            mtxtTC.Clear();
            mtxtTel.Clear();
            rbWoman.PerformClick();
        }
    }
}
