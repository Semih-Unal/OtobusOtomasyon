﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//---------------------------
using BAP.Common;
using BAP.Entity;
using BAP.Dal;
using System.IO;

namespace BAP.UI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        seferDal sfrDal = new seferDal();
        sehirDal cityDal = new sehirDal();
        otobusDal busDal = new otobusDal();
        biletDal bltDal = new biletDal();

        private void Form1_Load(object sender, EventArgs e)
        {
            panelBilet.Visible = true;
            panelBilet.Location = new Point(16, 92);
            panelTakip.Visible = false;
            panelKontrol.Visible = false;
            this.Size = new Size(784, 533);
            butonColor(btnBilet);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Forms.frmLogin loginScreen = new Forms.frmLogin();
            this.Hide();
            loginScreen.Show();
        }

        private void btnBilet_Click(object sender, EventArgs e)
        {
            Temizle();
            // Button Color
            butonColor(btnBilet);
            butonDefaultColor(btnKontrol);
            butonDefaultColor(btnTakip);
            // Panel Visible
            panelBilet.Visible = true;
            panelKontrol.Visible = false;
            panelTakip.Visible = false;
            panelBilet.Location = new Point(16,92);
        }

        private void btnTakip_Click(object sender, EventArgs e)
        {
            Temizle();
            // Button Color
            butonColor(btnTakip);
            butonDefaultColor(btnKontrol);
            butonDefaultColor(btnBilet);
            // Panel Visible
            panelBilet.Visible = false;
            panelKontrol.Visible = false;
            panelTakip.Visible = true;
            panelTakip.Location = new Point(16, 92);
            AraclariGetir(cbOtobus);
        }

        private void btnKontrol_Click(object sender, EventArgs e)
        {

            Temizle();
            // Button Color
            butonColor(btnKontrol);
            butonDefaultColor(btnTakip);
            butonDefaultColor(btnBilet);
            // Panel Visible
            panelBilet.Visible = false;
            panelKontrol.Visible = true;
            panelTakip.Visible = false;
            panelKontrol.Location = new Point(16, 92);
            BiletleriGetir();

            AraclariGetir(cbKontrolOtobus);

        }

        private void Temizle()
        {
            // Bilet Kes
            dTpTarih.Value = DateTime.Now;
            cbKalkis.Items.Clear();
            cbKalkis.Text = "- Seçiniz -";
            cbVaris.Items.Clear();
            cbVaris.Text = "- Seçiniz -";

            // Kontrol
            dGwBiletler.Rows.Clear();
            txtKontrolHasılat.Clear();

            // Araç Takip

            cbOtobus.SelectedIndex = -1;
            pbTakipResim.Image = null;
            lblMarka.Text = "";
            lblSofor.Text = "";

            dGwTakip.Rows.Clear();

        }

        private void butonDefaultColor(Button btn)
        {
            btn.BackColor = Color.FromArgb(128, 128, 255);
            btn.FlatAppearance.BorderColor = Color.White;
            btn.ForeColor = Color.White;
        }

        private void butonColor(Button btn)
        {
            btn.BackColor = Color.White;
            btn.FlatAppearance.BorderColor = Color.FromArgb(128, 128, 255);
            btn.ForeColor = Color.FromArgb(128, 128, 255);
        }
        #region Bilet Kes
        private void dTpTarih_ValueChanged(object sender, EventArgs e)
        {
            KalkisYeriGetir();
            cbKalkis.SelectedIndex = -1;
            cbVaris.SelectedIndex = -1;
            cbVaris.Text = "- Seçiniz -";
        }

        private void KalkisYeriGetir()
        {
            cbKalkis.Items.Clear();
            cbVaris.Text = "- Seçiniz -";
            var list = sfrDal.ListOfSeferKalkisbyDate(dTpTarih.Value.ToShortDateString());
            if (list.TransactionResult.Count == 0)
            {
                MessageBox.Show("Seçmiş olduğunuz tarihte seferimiz bulunmamaktadır ...");
                return;
            }
            foreach (Sefer s in list.TransactionResult)
            {
                Sehir shr = cityDal.SelectSehirbyId(s.Kalkis).TransactionResult;
                cbKalkis.Items.Add(shr);
            }
        }

        private void cbKalkis_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbVaris.Items.Clear();
            Sehir secilenYer = cbKalkis.SelectedItem as Sehir;
            var list = sfrDal.ListOfSeferVarisbyDateandKalkis(dTpTarih.Value.ToShortDateString(), secilenYer.Id);
            if (list.TransactionResult.Count == 0)
            {
                MessageBox.Show("Seçmiş olduğunuz tarihte ve hareket yerinden seferimiz bulunmamaktadır ...");
                return;
            }
            foreach (Sefer s in list.TransactionResult)
            {
                Sehir shr = cityDal.SelectSehirbyId(s.Varis).TransactionResult;
                cbVaris.Items.Add(shr);
            }
        }

        private void btnSeferSorgula_Click(object sender, EventArgs e)
        {
            Sehir secilenKYer = cbKalkis.SelectedItem as Sehir;
            Sehir secilenVYer = cbVaris.SelectedItem as Sehir;
            Sefer sfr = sfrDal.ListOfSeferbyDateandKalkisandVaris(dTpTarih.Value.ToShortDateString(), secilenKYer.Id, secilenVYer.Id).TransactionResult;//sfrDal
            string simdikiTarih = DateTime.Now.ToString("dd.MM.yyyy");
            string tarih = Convert.ToDateTime(sfr.Tarih).ToString("dd.MM.yyyy");
            //if (DateTime.Compare(Convert.ToDateTime(sfr.Tarih), DateTime.Now) < 0)
            //{
            //    MessageBox.Show("Bu Tarihteki Sefer Bilet Alım İşlemleri İçin Uygun Değildir !!!");
            //    return;
            //}
            Forms.frmBilet frmSorgu = new Forms.frmBilet(sfr);
            this.Hide();
            frmSorgu.Show();
        }
        #endregion

        #region Kontrol


        private void BiletleriGetir()
        {
            //Plaka, Koltuk No, sefer kalkış->varış, Ad Soyad, Bilet Tipi, Tutar
            dGwBiletler.Rows.Clear();
            var bltList = bltDal.ListOfBilet().TransactionResult;
            string bltDurum = "";
            foreach (Bilet blt in bltList)
            {

                Sefer seciliSefer = sfrDal.ListOfSeferbyId(blt.SeferId).TransactionResult;

                Otobus seciliOtobus = busDal.ListOfOtobusById(seciliSefer.OtobusId).TransactionResult;

                Sehir shrKalkis = cityDal.SelectSehirbyId(seciliSefer.Kalkis).TransactionResult;
                Sehir shrVaris = cityDal.SelectSehirbyId(seciliSefer.Varis).TransactionResult;
                if (blt.Durum == 1)
                    bltDurum = "Satın Alındı.";
                else if (blt.Durum == 2)
                    bltDurum = "Rezerve Edildi.";
                else
                    bltDurum = "Boş";
                dGwBiletler.Rows.Add(seciliOtobus.Plaka,blt.Koltuk, shrKalkis.SehirAdi+" -> "+shrVaris.SehirAdi,blt.YolcuAdSoyad,bltDurum,blt.ToplamFiyat,seciliSefer.Id,blt.Id);
            }
           dGwBiletler.Columns[6].Visible = false;
           dGwBiletler.Columns[7].Visible = false;

        }

        private void cbKontrolOtobus_SelectionChangeCommitted(object sender, EventArgs e)
        {
            dGwBiletler.Rows.Clear();
            Otobus secilenOtobus = cbKontrolOtobus.SelectedItem as Otobus;

            var sfrListbyOtoId = sfrDal.ListOfSeferbyOtoId(secilenOtobus.Id).TransactionResult;
            string bltDurum = "";
            decimal hasilat = 0;
            foreach (Sefer sefer in sfrListbyOtoId)
            {
                var bltList = bltDal.ListOfBiletbySeferId(sefer.Id).TransactionResult;
                Sehir shrKalkis = cityDal.SelectSehirbyId(sefer.Kalkis).TransactionResult;
                Sehir shrVaris = cityDal.SelectSehirbyId(sefer.Varis).TransactionResult;
                foreach (Bilet bilet in bltList)
                {
                    if (bilet.Durum == 1)
                    { 
                        bltDurum = "Satın Alındı.";
                        hasilat += bilet.ToplamFiyat;
                    }
                    else if (bilet.Durum == 2)
                    { 
                        bltDurum = "Rezerve Edildi.";
                    }
                    else
                    {
                        bltDurum = "Boş";
                    }
                    dGwBiletler.Rows.Add(secilenOtobus.Plaka, bilet.Koltuk, shrKalkis.SehirAdi + " -> " + shrVaris.SehirAdi, bilet.YolcuAdSoyad, bltDurum, bilet.ToplamFiyat,bilet.SeferId,bilet.Id);
                }
            }
            dGwBiletler.Columns[6].Visible = false;
            dGwBiletler.Columns[7].Visible = false;
            txtKontrolHasılat.Text = hasilat.ToString();
        }

        private void dGwBiletler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dGwBiletler.CurrentRow.Cells[4].Value.ToString() == "Rezerve Edildi.")
            {
                if (MessageBox.Show("Rezerve Edilen Bileti Satın Almak İster Misiniz?", "Bilet Satın Alma", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                {
                    int id = Convert.ToInt32(dGwBiletler.CurrentRow.Cells[6].Value);
                    Sefer sfr = sfrDal.ListOfSeferbyId(id).TransactionResult;//sfrDal

                    string suankiZaman = DateTime.Now.ToShortTimeString();
                    string hareketZamani = sfr.Saat;
                    TimeSpan kalanSure = DateTime.Parse(hareketZamani).Subtract(DateTime.Parse(suankiZaman));
                    if (kalanSure.Hours < 1)
                    {
                        MessageBox.Show("Rezerve Süresi Dolmuştur. ");
                        bltDal.Delete((int)dGwBiletler.CurrentRow.Cells[7].Value);
                    }
                    else
                    {
                        Forms.frmBilet frmSorgu = new Forms.frmBilet(sfr);
                        this.Hide();
                        frmSorgu.Show();
                    }
                }
            }
        }
        #endregion

        #region Araç Takip
        private void AraclariGetir(ComboBox cb)
        {
            var list = busDal.ListOfOtobus();

            cb.DataSource = list.TransactionResult;
            cb.DisplayMember = "Plaka";
        }
        private void cbOtobus_SelectionChangeCommitted(object sender, EventArgs e)
        {
            Otobus seciliBus = cbOtobus.SelectedItem as Otobus;
            pbTakipResim.Image = Image.FromFile(seciliBus.Resim);
            lblMarka.Text = seciliBus.Marka;
            lblSofor.Text = seciliBus.SoforAdSoyad;
            SeferleriGetir(seciliBus.Id, seciliBus.KoltukSayisi);
        }

        private void SeferleriGetir(int otoId, int koltukSayisi)
        {
            dGwTakip.Rows.Clear();
            var list = sfrDal.ListOfSeferbyOtoId(otoId);
            string suankiZaman = DateTime.Now.ToShortTimeString();
            foreach (Sefer sfr in list.TransactionResult)
            {
                Sehir shrKalkis = cityDal.SelectSehirbyId(sfr.Kalkis).TransactionResult;
                Sehir shrVaris = cityDal.SelectSehirbyId(sfr.Varis).TransactionResult;
                var listBilet = bltDal.ListOfBiletbySeferId(sfr.Id).TransactionResult;
                int biletAdet = 0;
                string hareketZamani = sfr.Saat;
                foreach (Bilet blt in listBilet)
                {
                    if (blt.Durum == 1)
                    {
                        biletAdet += 1;
                    }
                }

                TimeSpan kalanSure = DateTime.Parse(hareketZamani).Subtract(DateTime.Parse(suankiZaman));
                string sonuc = "";
                string simdikiTarih = DateTime.Now.ToString("dd.MM.yyyy");
                string tarih = Convert.ToDateTime(sfr.Tarih).ToString("dd.MM.yyyy");
                if (DateTime.Compare(DateTime.Parse(hareketZamani), DateTime.Parse(suankiZaman)) < 0 || DateTime.Compare(Convert.ToDateTime(sfr.Tarih), DateTime.Now) < 0)
                {
                    sonuc = "Hareket etmiştir.";
                }
                else if (DateTime.Compare(Convert.ToDateTime(tarih), Convert.ToDateTime(simdikiTarih)) == 0)
                {
                    sonuc = kalanSure + " süresi vardır.";
                }
                else
                {
                    sonuc = "Hareket günü bugün değildir.";
                }

                int idx = dGwTakip.Rows.Add(shrKalkis + " -> " + shrVaris, Convert.ToDateTime(sfr.Tarih).ToShortDateString(), sfr.Saat, koltukSayisi, listBilet.Count, sfr.Fiyat * biletAdet, sonuc);

                var row = dGwTakip.Rows[idx];
                if (sonuc == "Hareket etmiştir.")
                {
                    row.DefaultCellStyle.BackColor = Color.Red;
                    row.DefaultCellStyle.ForeColor = Color.White;
                }
            }
        }

        private void btnAracDurumu_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = @"C:\Users\Hp\Desktop";
            sfd.Filter = "TXT(.txt)|*.txt";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string filename = sfd.FileName;
                FileStream dosya = new FileStream(filename, FileMode.Append);


                StreamWriter dosyaYazici = new StreamWriter(dosya);

                Otobus seciliBus = cbOtobus.SelectedItem as Otobus;

                decimal genelToplam = 0;
                dosyaYazici.WriteLine(seciliBus.Plaka + " - Plakalı Aracın Genel Hasılat Arşivi - ");
                dosyaYazici.WriteLine();
                dosyaYazici.WriteLine("--------------------------------------------------");
                dosyaYazici.WriteLine();
                foreach (DataGridViewRow row in dGwTakip.Rows)
                {

                    dosyaYazici.WriteLine(seciliBus.Plaka + " - Plakalı Aracın " + Convert.ToDateTime(row.Cells[1].Value).ToString("dd.MM.yyyy") + " Tarihindeki Seferi - ");
                    dosyaYazici.WriteLine("--------------------------------------------------");
                    dosyaYazici.WriteLine("Sefer : " + row.Cells[0].Value);
                    dosyaYazici.WriteLine("Kalkış Saati : " + row.Cells[2].Value);
                    dosyaYazici.WriteLine("Koltuk Sayısı : " + row.Cells[3].Value);
                    dosyaYazici.WriteLine("Kişi Sayısı : " + row.Cells[4].Value);
                    dosyaYazici.WriteLine("Hasılat : " + row.Cells[5].Value);
                    dosyaYazici.WriteLine("****************************************************");

                    if (row.Cells[6].Value.ToString() == "Hareket etmiştir.")
                    {
                        genelToplam += Convert.ToDecimal(row.Cells[5].Value);
                    }
                }

                dosyaYazici.WriteLine("Genel Toplam Hasılat : " + genelToplam);
                dosyaYazici.WriteLine("--------------------------------------------------");
                dosyaYazici.Close();
                System.Diagnostics.Process.Start(filename);
            }
        }

        private void btnGunlukArsiv_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = @"C:\Users\Hp\Desktop";
            sfd.Filter = "TXT(.txt)|*.txt";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string filename = sfd.FileName;
                FileStream dosya = new FileStream(filename, FileMode.Append);


                StreamWriter dosyaYazici = new StreamWriter(dosya);

                Otobus seciliBus = cbOtobus.SelectedItem as Otobus;

                dosyaYazici.WriteLine(seciliBus.Plaka + " - Plakalı Araç Günlük Arşivi - " + DateTime.Now.ToLongDateString());
                dosyaYazici.WriteLine("--------------------------------------------------");
                decimal toplam = 0;
                string simdikiTarih = DateTime.Now.ToString("dd.MM.yyyy");

                foreach (DataGridViewRow row in dGwTakip.Rows)
                {

                    string tarih = Convert.ToDateTime(row.Cells[1].Value).ToString("dd.MM.yyyy");
                    if (DateTime.Compare(Convert.ToDateTime(tarih), Convert.ToDateTime(simdikiTarih)) == 0)
                    {
                        if (row.Cells[6].Value.ToString() == "Hareket etmiştir.")
                        {
                            dosyaYazici.WriteLine("Sefer : " + row.Cells[0].Value);
                            dosyaYazici.WriteLine("Kalkış Saati : " + row.Cells[2].Value);
                            dosyaYazici.WriteLine("Koltuk Sayısı : " + row.Cells[3].Value);
                            dosyaYazici.WriteLine("Kişi Sayısı : " + row.Cells[4].Value);
                            dosyaYazici.WriteLine("Hasılat : " + row.Cells[5].Value);
                            dosyaYazici.WriteLine("****************************************************");
                            toplam += Convert.ToDecimal(row.Cells[5].Value);
                        }
                    }
                }

                dosyaYazici.WriteLine("Toplam Hasılat : " + toplam);
                dosyaYazici.WriteLine("--------------------------------------------------");
                dosyaYazici.Close();
                System.Diagnostics.Process.Start(filename);
            }
        }

        #endregion
    }
}
