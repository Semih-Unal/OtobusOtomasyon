﻿namespace BAP.UI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnBilet = new System.Windows.Forms.Button();
            this.btnKontrol = new System.Windows.Forms.Button();
            this.btnTakip = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.panelBilet = new System.Windows.Forms.Panel();
            this.dTpTarih = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.cbVaris = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSeferSorgula = new System.Windows.Forms.Button();
            this.cbKalkis = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMarka = new System.Windows.Forms.Label();
            this.cbOtobus = new System.Windows.Forms.ComboBox();
            this.pbTakipResim = new System.Windows.Forms.PictureBox();
            this.panelTakip = new System.Windows.Forms.Panel();
            this.btnGunlukArsiv = new System.Windows.Forms.Button();
            this.btnAracDurumu = new System.Windows.Forms.Button();
            this.dGwTakip = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblSofor = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panelKontrol = new System.Windows.Forms.Panel();
            this.txtKontrolHasılat = new System.Windows.Forms.TextBox();
            this.dGwBiletler = new System.Windows.Forms.DataGridView();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbKontrolOtobus = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panelBilet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTakipResim)).BeginInit();
            this.panelTakip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwTakip)).BeginInit();
            this.panelKontrol.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwBiletler)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBilet
            // 
            this.btnBilet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnBilet.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBilet.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnBilet.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnBilet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBilet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBilet.ForeColor = System.Drawing.Color.White;
            this.btnBilet.Location = new System.Drawing.Point(16, 32);
            this.btnBilet.Name = "btnBilet";
            this.btnBilet.Size = new System.Drawing.Size(152, 39);
            this.btnBilet.TabIndex = 0;
            this.btnBilet.Text = "Bilet Kes";
            this.btnBilet.UseVisualStyleBackColor = false;
            this.btnBilet.Click += new System.EventHandler(this.btnBilet_Click);
            // 
            // btnKontrol
            // 
            this.btnKontrol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnKontrol.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKontrol.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnKontrol.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnKontrol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKontrol.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKontrol.ForeColor = System.Drawing.Color.White;
            this.btnKontrol.Location = new System.Drawing.Point(174, 32);
            this.btnKontrol.Name = "btnKontrol";
            this.btnKontrol.Size = new System.Drawing.Size(152, 39);
            this.btnKontrol.TabIndex = 0;
            this.btnKontrol.Text = "Kontrol";
            this.btnKontrol.UseVisualStyleBackColor = false;
            this.btnKontrol.Click += new System.EventHandler(this.btnKontrol_Click);
            // 
            // btnTakip
            // 
            this.btnTakip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnTakip.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTakip.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnTakip.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnTakip.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTakip.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTakip.ForeColor = System.Drawing.Color.White;
            this.btnTakip.Location = new System.Drawing.Point(332, 32);
            this.btnTakip.Name = "btnTakip";
            this.btnTakip.Size = new System.Drawing.Size(152, 39);
            this.btnTakip.TabIndex = 0;
            this.btnTakip.Text = "Araç Takip";
            this.btnTakip.UseVisualStyleBackColor = false;
            this.btnTakip.Click += new System.EventHandler(this.btnTakip_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnLogin.BackgroundImage = global::BAP.UI.Properties.Resources.customer_icon;
            this.btnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Location = new System.Drawing.Point(714, 12);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(35, 34);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // panelBilet
            // 
            this.panelBilet.Controls.Add(this.dTpTarih);
            this.panelBilet.Controls.Add(this.label2);
            this.panelBilet.Controls.Add(this.cbVaris);
            this.panelBilet.Controls.Add(this.label3);
            this.panelBilet.Controls.Add(this.label1);
            this.panelBilet.Controls.Add(this.btnSeferSorgula);
            this.panelBilet.Controls.Add(this.cbKalkis);
            this.panelBilet.Location = new System.Drawing.Point(16, 493);
            this.panelBilet.Name = "panelBilet";
            this.panelBilet.Size = new System.Drawing.Size(733, 193);
            this.panelBilet.TabIndex = 4;
            this.panelBilet.Visible = false;
            // 
            // dTpTarih
            // 
            this.dTpTarih.CustomFormat = "dd-MM-yyyy";
            this.dTpTarih.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dTpTarih.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dTpTarih.Location = new System.Drawing.Point(16, 80);
            this.dTpTarih.Name = "dTpTarih";
            this.dTpTarih.Size = new System.Drawing.Size(130, 26);
            this.dTpTarih.TabIndex = 2;
            this.dTpTarih.ValueChanged += new System.EventHandler(this.dTpTarih_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(358, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Varış Noktası :";
            // 
            // cbVaris
            // 
            this.cbVaris.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbVaris.FormattingEnabled = true;
            this.cbVaris.Location = new System.Drawing.Point(355, 80);
            this.cbVaris.Name = "cbVaris";
            this.cbVaris.Size = new System.Drawing.Size(189, 28);
            this.cbVaris.TabIndex = 0;
            this.cbVaris.Text = "- Seçiniz -";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(13, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Tarih :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(155, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Kalkış Noktası :";
            // 
            // btnSeferSorgula
            // 
            this.btnSeferSorgula.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnSeferSorgula.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnSeferSorgula.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnSeferSorgula.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnSeferSorgula.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSeferSorgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSeferSorgula.ForeColor = System.Drawing.Color.White;
            this.btnSeferSorgula.Location = new System.Drawing.Point(560, 80);
            this.btnSeferSorgula.Name = "btnSeferSorgula";
            this.btnSeferSorgula.Size = new System.Drawing.Size(156, 28);
            this.btnSeferSorgula.TabIndex = 0;
            this.btnSeferSorgula.Text = "Sefer Sorgula";
            this.btnSeferSorgula.UseVisualStyleBackColor = false;
            this.btnSeferSorgula.Click += new System.EventHandler(this.btnSeferSorgula_Click);
            // 
            // cbKalkis
            // 
            this.cbKalkis.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbKalkis.FormattingEnabled = true;
            this.cbKalkis.Location = new System.Drawing.Point(152, 80);
            this.cbKalkis.Name = "cbKalkis";
            this.cbKalkis.Size = new System.Drawing.Size(189, 28);
            this.cbKalkis.TabIndex = 0;
            this.cbKalkis.Text = "- Seçiniz -";
            this.cbKalkis.SelectionChangeCommitted += new System.EventHandler(this.cbKalkis_SelectionChangeCommitted);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(13, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Otobüs :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(13, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 17);
            this.label7.TabIndex = 1;
            this.label7.Text = "Araç :";
            // 
            // lblMarka
            // 
            this.lblMarka.AutoSize = true;
            this.lblMarka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMarka.Location = new System.Drawing.Point(64, 87);
            this.lblMarka.Name = "lblMarka";
            this.lblMarka.Size = new System.Drawing.Size(0, 17);
            this.lblMarka.TabIndex = 1;
            // 
            // cbOtobus
            // 
            this.cbOtobus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbOtobus.FormattingEnabled = true;
            this.cbOtobus.Location = new System.Drawing.Point(16, 45);
            this.cbOtobus.Name = "cbOtobus";
            this.cbOtobus.Size = new System.Drawing.Size(169, 28);
            this.cbOtobus.TabIndex = 0;
            this.cbOtobus.Text = "- Seçiniz -";
            this.cbOtobus.SelectionChangeCommitted += new System.EventHandler(this.cbOtobus_SelectionChangeCommitted);
            // 
            // pbTakipResim
            // 
            this.pbTakipResim.Location = new System.Drawing.Point(16, 138);
            this.pbTakipResim.Name = "pbTakipResim";
            this.pbTakipResim.Size = new System.Drawing.Size(169, 133);
            this.pbTakipResim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTakipResim.TabIndex = 2;
            this.pbTakipResim.TabStop = false;
            // 
            // panelTakip
            // 
            this.panelTakip.Controls.Add(this.btnGunlukArsiv);
            this.panelTakip.Controls.Add(this.btnAracDurumu);
            this.panelTakip.Controls.Add(this.dGwTakip);
            this.panelTakip.Controls.Add(this.lblSofor);
            this.panelTakip.Controls.Add(this.pbTakipResim);
            this.panelTakip.Controls.Add(this.cbOtobus);
            this.panelTakip.Controls.Add(this.lblMarka);
            this.panelTakip.Controls.Add(this.label4);
            this.panelTakip.Controls.Add(this.label7);
            this.panelTakip.Controls.Add(this.label5);
            this.panelTakip.Location = new System.Drawing.Point(755, 90);
            this.panelTakip.Name = "panelTakip";
            this.panelTakip.Size = new System.Drawing.Size(733, 385);
            this.panelTakip.TabIndex = 3;
            this.panelTakip.Visible = false;
            // 
            // btnGunlukArsiv
            // 
            this.btnGunlukArsiv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnGunlukArsiv.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnGunlukArsiv.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnGunlukArsiv.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnGunlukArsiv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGunlukArsiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGunlukArsiv.ForeColor = System.Drawing.Color.White;
            this.btnGunlukArsiv.Location = new System.Drawing.Point(500, 341);
            this.btnGunlukArsiv.Name = "btnGunlukArsiv";
            this.btnGunlukArsiv.Size = new System.Drawing.Size(212, 32);
            this.btnGunlukArsiv.TabIndex = 5;
            this.btnGunlukArsiv.Text = "Günlük Arşiv";
            this.btnGunlukArsiv.UseVisualStyleBackColor = false;
            this.btnGunlukArsiv.Click += new System.EventHandler(this.btnGunlukArsiv_Click);
            // 
            // btnAracDurumu
            // 
            this.btnAracDurumu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnAracDurumu.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnAracDurumu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnAracDurumu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnAracDurumu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAracDurumu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAracDurumu.ForeColor = System.Drawing.Color.White;
            this.btnAracDurumu.Location = new System.Drawing.Point(229, 341);
            this.btnAracDurumu.Name = "btnAracDurumu";
            this.btnAracDurumu.Size = new System.Drawing.Size(239, 32);
            this.btnAracDurumu.TabIndex = 5;
            this.btnAracDurumu.Text = "Araç Durumu Kaydet";
            this.btnAracDurumu.UseVisualStyleBackColor = false;
            this.btnAracDurumu.Click += new System.EventHandler(this.btnAracDurumu_Click);
            // 
            // dGwTakip
            // 
            this.dGwTakip.AllowUserToAddRows = false;
            this.dGwTakip.AllowUserToOrderColumns = true;
            this.dGwTakip.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGwTakip.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column4,
            this.Column5,
            this.Column2,
            this.Column3,
            this.Column6,
            this.Column7});
            this.dGwTakip.Location = new System.Drawing.Point(229, 45);
            this.dGwTakip.MultiSelect = false;
            this.dGwTakip.Name = "dGwTakip";
            this.dGwTakip.ReadOnly = true;
            this.dGwTakip.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwTakip.Size = new System.Drawing.Size(483, 272);
            this.dGwTakip.TabIndex = 4;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Sefer";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 70;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Tarih";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 90;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Saat";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 50;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Koltuk Sayısı";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 50;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Kişi Sayısı";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 80;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Hasılat";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Araç Durumu";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // lblSofor
            // 
            this.lblSofor.AutoSize = true;
            this.lblSofor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSofor.Location = new System.Drawing.Point(75, 111);
            this.lblSofor.Name = "lblSofor";
            this.lblSofor.Size = new System.Drawing.Size(0, 17);
            this.lblSofor.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(14, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Şoför :";
            // 
            // panelKontrol
            // 
            this.panelKontrol.Controls.Add(this.txtKontrolHasılat);
            this.panelKontrol.Controls.Add(this.dGwBiletler);
            this.panelKontrol.Controls.Add(this.cbKontrolOtobus);
            this.panelKontrol.Controls.Add(this.label8);
            this.panelKontrol.Controls.Add(this.label6);
            this.panelKontrol.Controls.Add(this.label11);
            this.panelKontrol.Location = new System.Drawing.Point(16, 90);
            this.panelKontrol.Name = "panelKontrol";
            this.panelKontrol.Size = new System.Drawing.Size(733, 385);
            this.panelKontrol.TabIndex = 5;
            this.panelKontrol.Visible = false;
            // 
            // txtKontrolHasılat
            // 
            this.txtKontrolHasılat.Enabled = false;
            this.txtKontrolHasılat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtKontrolHasılat.Location = new System.Drawing.Point(239, 344);
            this.txtKontrolHasılat.Name = "txtKontrolHasılat";
            this.txtKontrolHasılat.Size = new System.Drawing.Size(143, 29);
            this.txtKontrolHasılat.TabIndex = 6;
            // 
            // dGwBiletler
            // 
            this.dGwBiletler.AllowUserToAddRows = false;
            this.dGwBiletler.AllowUserToOrderColumns = true;
            this.dGwBiletler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGwBiletler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15});
            this.dGwBiletler.Location = new System.Drawing.Point(22, 45);
            this.dGwBiletler.MultiSelect = false;
            this.dGwBiletler.Name = "dGwBiletler";
            this.dGwBiletler.ReadOnly = true;
            this.dGwBiletler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwBiletler.Size = new System.Drawing.Size(690, 252);
            this.dGwBiletler.TabIndex = 4;
            this.dGwBiletler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGwBiletler_CellClick);
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Plaka";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Koltuk No";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Sefer Kalkış -> Varış";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 150;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Ad Soyad";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Bilet Tipi";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Tutar";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "SeferId";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "BiletId";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // cbKontrolOtobus
            // 
            this.cbKontrolOtobus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbKontrolOtobus.FormattingEnabled = true;
            this.cbKontrolOtobus.Location = new System.Drawing.Point(22, 345);
            this.cbKontrolOtobus.Name = "cbKontrolOtobus";
            this.cbKontrolOtobus.Size = new System.Drawing.Size(169, 28);
            this.cbKontrolOtobus.TabIndex = 0;
            this.cbKontrolOtobus.Text = "- Seçiniz -";
            this.cbKontrolOtobus.SelectedIndexChanged += new System.EventHandler(this.cbKontrolOtobus_SelectionChangeCommitted);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(388, 350);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "TL";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(236, 320);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 17);
            this.label6.TabIndex = 1;
            this.label6.Text = "Hasılat:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(19, 320);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(62, 17);
            this.label11.TabIndex = 1;
            this.label11.Text = "Otobüs :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1296, 750);
            this.Controls.Add(this.panelKontrol);
            this.Controls.Add(this.panelBilet);
            this.Controls.Add(this.panelTakip);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.btnKontrol);
            this.Controls.Add(this.btnTakip);
            this.Controls.Add(this.btnBilet);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Otobüs Otomasyonu";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelBilet.ResumeLayout(false);
            this.panelBilet.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTakipResim)).EndInit();
            this.panelTakip.ResumeLayout(false);
            this.panelTakip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwTakip)).EndInit();
            this.panelKontrol.ResumeLayout(false);
            this.panelKontrol.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGwBiletler)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBilet;
        private System.Windows.Forms.Button btnKontrol;
        private System.Windows.Forms.Button btnTakip;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Panel panelBilet;
        private System.Windows.Forms.DateTimePicker dTpTarih;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbVaris;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSeferSorgula;
        private System.Windows.Forms.ComboBox cbKalkis;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblMarka;
        private System.Windows.Forms.ComboBox cbOtobus;
        private System.Windows.Forms.PictureBox pbTakipResim;
        private System.Windows.Forms.Panel panelTakip;
        private System.Windows.Forms.Label lblSofor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dGwTakip;
        private System.Windows.Forms.Button btnGunlukArsiv;
        private System.Windows.Forms.Button btnAracDurumu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.Panel panelKontrol;
        private System.Windows.Forms.TextBox txtKontrolHasılat;
        private System.Windows.Forms.DataGridView dGwBiletler;
        private System.Windows.Forms.ComboBox cbKontrolOtobus;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
    }
}

