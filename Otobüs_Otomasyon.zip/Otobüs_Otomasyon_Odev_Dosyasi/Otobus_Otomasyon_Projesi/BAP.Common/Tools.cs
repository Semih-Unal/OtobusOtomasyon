﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAP.Common
{
    public class Tools
    {
        public static string ConectionString
        {
            get
            {
                return "Server = .; Database = FirmaDB; UID = sa; PWD = 1234"; // veya Integrated Security = True veya Yes
            }
        }
    }
}
