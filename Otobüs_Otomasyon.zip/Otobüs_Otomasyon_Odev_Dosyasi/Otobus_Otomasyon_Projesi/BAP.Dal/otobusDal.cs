﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//--------------------
using BAP.Entity;
using BAP.Common;
using System.Data.SqlClient;

namespace BAP.Dal
{
    public class otobusDal
    {

        // ID ye Göre Listeleme

        public Result<Otobus> ListOfOtobusById(object instanceId)
        {
            Result<Otobus> rlc = new Result<Otobus>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Otobus Where OtobusId = @Id ", false);

            sqlProvider.AddParameter("@Id", instanceId);
            SqlDataReader reader = sqlProvider.ExecuteReader();

            rlc.IsSucceeded = rlc != null;

            Otobus Bus = new Otobus();

            if (reader.HasRows)
            {
                while (reader.Read())
                {

                    Bus.Id = Convert.ToInt32(reader["OtobusId"]);
                    Bus.SoforAdSoyad = reader["SoforAdSoyad"].ToString();
                    Bus.Plaka = reader["Plaka"].ToString();
                    Bus.Marka = reader["Marka"].ToString();
                    Bus.KoltukSayisi = Convert.ToInt32(reader["KoltukSayisi"]);
                    Bus.Resim = reader["Resim"].ToString();
                    Bus.CreateDate = Convert.ToDateTime(reader["CreateDate"]);
                    
                }
            }
            reader.Close();

            rlc.TransactionResult = Bus;

            return rlc;
        }

        // Listele

        public Result<List<Otobus>> ListOfOtobus()
        {
            Result<List<Otobus>> rlc = new Result<List<Otobus>>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Otobus",false);

            SqlDataReader reader = sqlProvider.ExecuteReader();

            rlc.IsSucceeded = rlc != null;

            List<Otobus> allBus = new List<Otobus>();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Otobus o = new Otobus();

                    o.Id = Convert.ToInt32(reader["OtobusId"]);
                    o.SoforAdSoyad = reader["SoforAdSoyad"].ToString();
                    o.Plaka = reader["Plaka"].ToString();
                    o.Marka = reader["Marka"].ToString();
                    o.KoltukSayisi = Convert.ToInt32(reader["KoltukSayisi"]);
                    o.Resim = reader["Resim"].ToString();
                    o.CreateDate = Convert.ToDateTime(reader["CreateDate"]);

                    allBus.Add(o);
                }
            }
            reader.Close();

            rlc.TransactionResult = allBus;

            return rlc;
        }

        // Ekle

        public Result Save(Otobus instance)
        {
            Result result = new Result();

            int resultValue = 0;

            SqlProvider sqlProvider = new SqlProvider("Insert Into Otobus (SoforAdSoyad, Plaka, Marka, KoltukSayisi, Resim, CreateDate) values (@SoforAdSoyad, @Plaka, @Marka, @KoltukSayisi, @Resim, @CreateDate)",false);

            sqlProvider.AddParameter("@SoforAdSoyad",instance.SoforAdSoyad);
            sqlProvider.AddParameter("@Plaka", instance.Plaka);
            sqlProvider.AddParameter("@Marka", instance.Marka);
            sqlProvider.AddParameter("@KoltukSayisi", instance.KoltukSayisi);
            sqlProvider.AddParameter("@Resim", instance.Resim);
            sqlProvider.AddParameter("@CreateDate", instance.CreateDate);

            resultValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = resultValue != 0;

            return result;

        }

        // Güncelle

        public Result Update(Otobus instance)
        {
            Result result = new Result();

            int resultValue = 0;

            SqlProvider sqlProvider = new SqlProvider("Update Otobus Set SoforAdSoyad = @SoforAdSoyad, Plaka = @Plaka, Marka = @Marka, KoltukSayisi = @KoltukSayisi, Resim = @Resim, CreateDate = @CreateDate Where OtobusId = @Id", false);

            sqlProvider.AddParameter("@Id", instance.Id);
            sqlProvider.AddParameter("@SoforAdSoyad", instance.SoforAdSoyad);
            sqlProvider.AddParameter("@Plaka", instance.Plaka);
            sqlProvider.AddParameter("@Marka", instance.Marka);
            sqlProvider.AddParameter("@KoltukSayisi", instance.KoltukSayisi);
            sqlProvider.AddParameter("@Resim", instance.Resim);
            sqlProvider.AddParameter("@CreateDate", instance.CreateDate);

            resultValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = resultValue != 0;

            return result;
        }

        // Sil

        public Result Delete(object instanceId)
        {
            Result result = new Result();

            int resultValue = 0;

            SqlProvider sqlProvider = new SqlProvider("Delete From Otobus Where OtobusId = @Id", false);

            sqlProvider.AddParameter("@Id", instanceId);

            resultValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = resultValue != 0;

            return result;
        }


    }
}
