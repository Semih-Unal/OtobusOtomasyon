﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//-------------------
using BAP.Common;
using System.Data.SqlClient; // ekledik. 
using System.Data; // ConnectionState için ekledik.
namespace BAP.Dal
{
   public class SqlProvider
    {
        // Sql bağlantısı
        private SqlConnection cnn;
        private SqlCommand cmd;

        public SqlProvider(string commandText, bool isProcedure) // ctor 
        {
            cnn = new SqlConnection(Tools.ConectionString);
            cmd = new SqlCommand(commandText, cnn);

            cmd.CommandType = isProcedure == true ? CommandType.StoredProcedure : CommandType.Text;
        }

        // Parametre

        public void AddParameter(string parameterName, object value)
        {
            cmd.Parameters.AddWithValue(parameterName,value);
        }

        // Connection

        public void OpenConnection()
        {
            if (cnn.State == ConnectionState.Closed)
                cnn.Open();
        }
        public void CloseConnection()
        {
            if (cnn.State == ConnectionState.Open)
                cnn.Close();
        }

        // Select için;
        public SqlDataReader ExecuteReader()
        {
            OpenConnection();

            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
            // otomatikmen veri çekimi bittiğinde iletişim de kapatılır ...

            // CloseConnection();
        }

        //------------------------------------------------------
        // Insert / Update / Delete için;
        public int ExecuteNonQuery()
        {
            int result = -1;

            try
            {
                OpenConnection();
                result = cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                result = -1;
            }
            finally
            {
                CloseConnection();
            }
            return result;
        }

        // --------------------------------------------------
        // Scalar için;
        public object ExecuteScalar()
        {
            object result = null;

            try
            {
                OpenConnection();
                result = cmd.ExecuteScalar();
            }
            catch (Exception)
            {
                result = null;
            }
            finally
            {
                CloseConnection();
            }
            return result;
        }
    }
}
