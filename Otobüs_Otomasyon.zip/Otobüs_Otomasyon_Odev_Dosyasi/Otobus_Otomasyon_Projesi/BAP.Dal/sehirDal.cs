﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//--------------------
using BAP.Entity;
using BAP.Common;
using System.Data.SqlClient;

namespace BAP.Dal
{
    public class sehirDal
    {
        public Result<Sehir> SelectSehirbyId(object instanceId)
        {
            Result<Sehir> rlc = new Result<Sehir>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Sehir Where SehirId = @Id", false);

            sqlProvider.AddParameter("@Id",instanceId);
            SqlDataReader reader = sqlProvider.ExecuteReader();

            rlc.IsSucceeded = rlc != null;


            Sehir city = new Sehir();

            if (reader.HasRows)
            {
                while (reader.Read())
                {

                    city.Id = Convert.ToInt32(reader["SehirId"]);
                    city.SehirAdi = reader["SehirAdi"].ToString();
                    city.CreateDate = Convert.ToDateTime(reader["CreateDate"]);
                }
            }
            reader.Close();

            rlc.TransactionResult = city;

            return rlc;
        }

        public Result<List<Sehir>> ListOfSehirbyId(int removeId)
        {
            Result<List<Sehir>> rlc = new Result<List<Sehir>>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Sehir", false);

            SqlDataReader reader = sqlProvider.ExecuteReader();

            rlc.IsSucceeded = rlc != null;

            List<Sehir> cities = new List<Sehir>();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    if (removeId != Convert.ToInt32(reader["SehirId"]))
                    {
                        Sehir city = new Sehir();

                        city.Id = Convert.ToInt32(reader["SehirId"]);
                        city.SehirAdi = reader["SehirAdi"].ToString();
                        city.CreateDate = Convert.ToDateTime(reader["CreateDate"]);

                        cities.Add(city);
                    }
                }
            }
            reader.Close();

            rlc.TransactionResult = cities;

            return rlc;
        }

        public Result<List<Sehir>> ListOfSehir()
        {
            Result<List<Sehir>> rlc = new Result<List<Sehir>>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Sehir",false);

            SqlDataReader reader = sqlProvider.ExecuteReader();

            rlc.IsSucceeded = rlc != null;

            List<Sehir> cities = new List<Sehir>();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Sehir city = new Sehir();

                    city.Id = Convert.ToInt32(reader["SehirId"]);
                    city.SehirAdi = reader["SehirAdi"].ToString();
                    city.CreateDate = Convert.ToDateTime(reader["CreateDate"]);

                    cities.Add(city);
                }
            }
            reader.Close();

            rlc.TransactionResult = cities;

            return rlc;
        }
    }
}
