﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//--------------------
using BAP.Entity;
using BAP.Common;
using System.Data.SqlClient;

namespace BAP.Dal
{
    public class biletDal
    {
        // Sefer Id ye göre
        public Result<List<Bilet>> ListOfBiletbySeferId(object instancesfrId)
        {
            Result<List<Bilet>> rlc = new Result<List<Bilet>>();
            

            SqlProvider sqlProvider = new SqlProvider("Select * From Bilet Where SeferId = @SeferId", false);

            sqlProvider.AddParameter("@SeferId", instancesfrId);
            SqlDataReader reader = sqlProvider.ExecuteReader();
            rlc.IsSucceeded = rlc != null;


            List<Bilet> biletler = new List<Bilet>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Bilet b = new Bilet();
                    b.Id = Convert.ToInt32(reader["BiletId"]);
                    b.Adet = Convert.ToInt32(reader["Adet"]);
                    b.ToplamFiyat = Convert.ToDecimal(reader["ToplamFiyat"]);
                    b.YolcuAdSoyad = reader["YolcuAdSoyad"].ToString();
                    b.YolcuTC = Convert.ToInt64(reader["YolcuTC"]); 
                    b.YolcuTel = reader["YolcuTel"].ToString();
                    b.Cinsiyet = Convert.ToBoolean(reader["Cinsiyet"]);
                    b.Koltuk = Convert.ToInt32(reader["Koltuk"]);
                    b.Durum = Convert.ToInt32(reader["Durum"]);
                    b.SeferId = Convert.ToInt32(reader["SeferId"]);

                    biletler.Add(b);
                }
            }
            reader.Close();

            rlc.TransactionResult = biletler;

            return rlc;
        }
        // Listele
        public Result<List<Bilet>> ListOfBilet()
        {
            Result<List<Bilet>> rlc = new Result<List<Bilet>>();
            

            SqlProvider sqlProvider = new SqlProvider("Select * From Bilet", false);
            

            SqlDataReader reader = sqlProvider.ExecuteReader();
            rlc.IsSucceeded = rlc != null;


            List<Bilet> biletler = new List<Bilet>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Bilet b = new Bilet();
                    b.Id = Convert.ToInt32(reader["BiletId"]);
                    b.Adet = Convert.ToInt32(reader["Adet"]);
                    b.ToplamFiyat = Convert.ToDecimal(reader["ToplamFiyat"]);
                    b.YolcuAdSoyad = reader["YolcuAdSoyad"].ToString();
                    b.YolcuTC = Convert.ToInt64(reader["YolcuTC"]);
                    b.YolcuTel = reader["YolcuTel"].ToString();
                    b.Cinsiyet = Convert.ToBoolean(reader["Cinsiyet"]);
                    b.Koltuk = Convert.ToInt32(reader["Koltuk"]);
                    b.Durum = Convert.ToInt32(reader["Durum"]);
                    b.SeferId = Convert.ToInt32(reader["SeferId"]);

                    biletler.Add(b);
                }
            }
            reader.Close();

            rlc.TransactionResult = biletler;

            return rlc;
        }
        //Ekle
        public Result Save(Bilet instance)
        {
            Result result = new Result();

            int resultValue = 0;
            SqlProvider sqlProvider = new SqlProvider("Insert Into Bilet (Adet,ToplamFiyat,YolcuAdSoyad,YolcuTC,YolcuTel,Cinsiyet,Koltuk,Durum,CreateDate,SeferId) values (@Adet,@ToplamFiyat,@YolcuAdSoyad,@YolcuTC,@YolcuTel,@Cinsiyet,@Koltuk,@Durum,@CreateDate,@SeferId)", false);

            sqlProvider.AddParameter("@Adet", instance.Adet);
            sqlProvider.AddParameter("@ToplamFiyat", instance.ToplamFiyat);
            sqlProvider.AddParameter("@YolcuAdSoyad", instance.YolcuAdSoyad);
            sqlProvider.AddParameter("@YolcuTC", instance.YolcuTC);
            sqlProvider.AddParameter("@YolcuTel", instance.YolcuTel);
            sqlProvider.AddParameter("@Cinsiyet", instance.Cinsiyet);
            sqlProvider.AddParameter("@Koltuk", instance.Koltuk);
            sqlProvider.AddParameter("@Durum", instance.Durum);
            sqlProvider.AddParameter("@CreateDate", instance.CreateDate);
            sqlProvider.AddParameter("@SeferId", instance.SeferId);

            resultValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = resultValue != -1;

            return result;
        }

        //Güncelle

        public Result Update(Bilet instance)
        {
            Result result = new Result();

            int resultValue = 0;

            SqlProvider sqlProvider = new SqlProvider("Update Bilet SET Adet = @Adet, ToplamFiyat = @ToplamFiyat, YolcuAdSoyad = @YolcuAdSoyad, YolcuTC = @YolcuTC, YolcuTel = @YolcuTel, Cinsiyet = @Cinsiyet, Koltuk = @Koltuk, Durum = @Durum, SeferId = @SeferId Where BiletId = @BiletId", false);

            sqlProvider.AddParameter("@BiletId", instance.Id);
            sqlProvider.AddParameter("@Adet", instance.Adet);
            sqlProvider.AddParameter("@ToplamFiyat", instance.ToplamFiyat);
            sqlProvider.AddParameter("@YolcuAdSoyad", instance.YolcuAdSoyad);
            sqlProvider.AddParameter("@YolcuTC", instance.YolcuTC);
            sqlProvider.AddParameter("@YolcuTel", instance.YolcuTel);
            sqlProvider.AddParameter("@Cinsiyet", instance.Cinsiyet);
            sqlProvider.AddParameter("@Koltuk", instance.Koltuk);
            sqlProvider.AddParameter("@Durum", instance.Durum);
            sqlProvider.AddParameter("@SeferId", instance.SeferId);

            resultValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = resultValue != -1;

            return result;
        }
        //Sil

        public Result Delete(object instanceId)
        {
            Result result = new Result();

            int resultValue = 0;

            SqlProvider sqlProvider = new SqlProvider("DElete From Bilet Where BiletId = @BiletId", false);

            sqlProvider.AddParameter("@BiletId", instanceId);

            resultValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = resultValue != -1;

            return result;
        }
    }
}
