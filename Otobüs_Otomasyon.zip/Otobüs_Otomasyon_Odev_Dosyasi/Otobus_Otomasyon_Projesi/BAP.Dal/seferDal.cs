﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//--------------------
using BAP.Entity;
using BAP.Common;
using System.Data.SqlClient;

namespace BAP.Dal
{
    public class seferDal
    {
        public Result<List<Sefer>> ListOfSeferbyOtoId(object instanceId)
        {
            Result<List<Sefer>> rlc = new Result<List<Sefer>>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Sefer Where OtobusId = @Id", false);

            sqlProvider.AddParameter("@Id", instanceId);
            SqlDataReader reader = sqlProvider.ExecuteReader();

            rlc.IsSucceeded = rlc != null;

            List<Sefer> seferler = new List<Sefer>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {

                    Sefer s = new Sefer();
                    s.Id = Convert.ToInt32(reader["SeferId"]);
                    s.Kalkis = Convert.ToInt32(reader["Kalkis"]);
                    s.Varis = Convert.ToInt32(reader["Varis"]);
                    s.Saat = reader["Saat"].ToString();
                    s.SeferNo = Convert.ToInt32(reader["SeferNo"]);
                    s.Fiyat = Convert.ToDecimal(reader["Fiyat"]);
                    s.Tarih = Convert.ToDateTime(reader["Tarih"]);
                    s.CreateDate = Convert.ToDateTime(reader["CreateDate"]);
                    s.OtobusId = Convert.ToInt32(reader["OtobusId"]);

                    seferler.Add(s);
                }
            }
            reader.Close();

            rlc.TransactionResult = seferler;

            return rlc;
        }
        //Kalkış yerlerini tarihe göre listele tekrarsız
        public Result<List<Sefer>> ListOfSeferKalkisbyDate(object date)
        {
            Result<List<Sefer>> rlc = new Result<List<Sefer>>();

            StringBuilder strBuilder = new StringBuilder();

            SqlProvider sqlProvider = new SqlProvider("Select Distinct Kalkis From Sefer Where convert(varchar, Tarih, 104) = @Tarih", false);

            sqlProvider.AddParameter("@Tarih", date);
            SqlDataReader reader = sqlProvider.ExecuteReader();
            rlc.IsSucceeded = rlc != null;


            List<Sefer> seferler = new List<Sefer>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Sefer s = new Sefer();
                    s.Kalkis = Convert.ToInt32(reader["Kalkis"]);

                    seferler.Add(s);
                }
            }
            reader.Close();

            rlc.TransactionResult = seferler;

            return rlc;
        }
        // Varış yerlerini tarihe ve kalkış idye göre listele tekrarsız
        public Result<List<Sefer>> ListOfSeferVarisbyDateandKalkis(object date,object kId)
        {
            Result<List<Sefer>> rlc = new Result<List<Sefer>>();

            StringBuilder strBuilder = new StringBuilder();

            SqlProvider sqlProvider = new SqlProvider("Select Distinct Varis From Sefer Where convert(varchar, Tarih, 104) = @Tarih AND Kalkis = @Kalkis", false);

            sqlProvider.AddParameter("@Tarih", date);
            sqlProvider.AddParameter("@Kalkis", kId);
            SqlDataReader reader = sqlProvider.ExecuteReader();
            rlc.IsSucceeded = rlc != null;


            List<Sefer> seferler = new List<Sefer>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Sefer s = new Sefer();
                    s.Varis = Convert.ToInt32(reader["Varis"]);

                    seferler.Add(s);
                }
            }
            reader.Close();

            rlc.TransactionResult = seferler;

            return rlc;
        }
        // Varış yerlerini tarihe ve kalkış idye göre listele tekrarsız
        public Result<Sefer> ListOfSeferbyDateandKalkisandVaris(object date, object kId,object vId)
        {
            Result<Sefer> rlc = new Result<Sefer>();

            StringBuilder strBuilder = new StringBuilder();

            SqlProvider sqlProvider = new SqlProvider("Select * From Sefer Where convert(varchar, Tarih, 104) = @Tarih AND Kalkis = @Kalkis AND Varis = @Varis", false);

            sqlProvider.AddParameter("@Tarih", date);
            sqlProvider.AddParameter("@Kalkis", kId);
            sqlProvider.AddParameter("@Varis", vId);
            SqlDataReader reader = sqlProvider.ExecuteReader();
            rlc.IsSucceeded = rlc != null;


            Sefer s = new Sefer();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    s.Id = Convert.ToInt32(reader["SeferId"]);
                    s.Kalkis = Convert.ToInt32(reader["Kalkis"]);
                    s.Varis = Convert.ToInt32(reader["Varis"]);
                    s.Saat = reader["Saat"].ToString();
                    s.SeferNo = Convert.ToInt32(reader["SeferNo"]);
                    s.Fiyat = Convert.ToDecimal(reader["Fiyat"]);
                    s.Tarih = Convert.ToDateTime(reader["Tarih"]);
                    s.CreateDate = Convert.ToDateTime(reader["CreateDate"]);
                    s.OtobusId = Convert.ToInt32(reader["OtobusId"]);
                    
                }
            }
            reader.Close();

            rlc.TransactionResult = s;

            return rlc;
        }
        // Id ye görelistele
        public Result<Sefer> ListOfSeferbyId(object instanceId)
        {
            Result<Sefer> rlc = new Result<Sefer>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Sefer Where SeferId = @Id", false);

            sqlProvider.AddParameter("@Id", instanceId);
            SqlDataReader reader = sqlProvider.ExecuteReader();

            rlc.IsSucceeded = rlc != null;


            Sefer s = new Sefer();
            if (reader.HasRows)
            {
                while (reader.Read())
                {

                    s.Id = Convert.ToInt32(reader["SeferId"]);
                    s.Kalkis = Convert.ToInt32(reader["Kalkis"]);
                    s.Varis = Convert.ToInt32(reader["Varis"]);
                    s.Saat = reader["Saat"].ToString();
                    s.SeferNo = Convert.ToInt32(reader["SeferNo"]);
                    s.Fiyat = Convert.ToDecimal(reader["Fiyat"]);
                    s.Tarih = Convert.ToDateTime(reader["Tarih"]);
                    s.CreateDate = Convert.ToDateTime(reader["CreateDate"]);
                    s.OtobusId = Convert.ToInt32(reader["OtobusId"]);
                }
            }
            reader.Close();

            rlc.TransactionResult = s;

            return rlc;
        }

        // listele
        public Result<List<Sefer>> ListOfSefer()
        {
            Result<List<Sefer>> rlc = new Result<List<Sefer>>();

            SqlProvider sqlProvider = new SqlProvider("Select * From Sefer", false);

            SqlDataReader reader = sqlProvider.ExecuteReader();
            rlc.IsSucceeded = rlc != null;

            List<Sefer> seferler = new List<Sefer>();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Sefer s = new Sefer();

                    s.Id = Convert.ToInt32(reader["SeferId"]);
                    s.Kalkis = Convert.ToInt32(reader["Kalkis"]);
                    s.Varis = Convert.ToInt32(reader["Varis"]);
                    s.Saat = reader["Saat"].ToString();
                    s.SeferNo = Convert.ToInt32(reader["SeferNo"]);
                    s.Fiyat = Convert.ToDecimal(reader["Fiyat"]);
                    s.Tarih = Convert.ToDateTime(reader["Tarih"]);
                    s.CreateDate = Convert.ToDateTime(reader["CreateDate"]);
                    s.OtobusId = Convert.ToInt32(reader["OtobusId"]);

                    seferler.Add(s);
                }
            }
            reader.Close();

            rlc.TransactionResult = seferler;

            return rlc;
        }

        // Ekle 
        public Result Save(Sefer instance)
        {
            Result result = new Result();

            int returnValue = 0;
           

            SqlProvider sqlProvider = new SqlProvider("Insert Into Sefer (Kalkis, Varis, Tarih, SeferNo, Fiyat, Saat, CreateDate,OtobusId) values (@Kalkis, @Varis, @Tarih, @SeferNo, @Fiyat, @Saat, @CreateDate, @OtobusId)", false);

            sqlProvider.AddParameter("@Kalkis",instance.Kalkis);
            sqlProvider.AddParameter("@Varis", instance.Varis);
            sqlProvider.AddParameter("@Tarih", instance.Tarih);
            sqlProvider.AddParameter("@SeferNo", instance.SeferNo);
            sqlProvider.AddParameter("@Fiyat", instance.Fiyat);
            sqlProvider.AddParameter("@Saat", instance.Saat);
            sqlProvider.AddParameter("@CreateDate", instance.CreateDate);
            sqlProvider.AddParameter("@OtobusId", instance.OtobusId);

            returnValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = returnValue != -1;

            return result;

        }
        
        // Güncelle

        public Result Update(Sefer instance)
        {
            Result result = new Result();

            int returnValue = 0;


            SqlProvider sqlProvider = new SqlProvider("Update Sefer Set Kalkis=@Kalkis, Varis=@Varis, Tarih=@Tarih, SeferNo=@SeferNo, Fiyat=@Fiyat, Saat=@Saat, CreateDate=@CreateDate, OtobusId=@OtobusId Where SeferId=@Id", false);

            sqlProvider.AddParameter("@Id", instance.Id);
            sqlProvider.AddParameter("@Kalkis", instance.Kalkis);
            sqlProvider.AddParameter("@Varis", instance.Varis);
            sqlProvider.AddParameter("@Tarih", instance.Tarih);
            sqlProvider.AddParameter("@SeferNo", instance.SeferNo);
            sqlProvider.AddParameter("@Fiyat", instance.Fiyat);
            sqlProvider.AddParameter("@Saat", instance.Saat);
            sqlProvider.AddParameter("@CreateDate", instance.CreateDate);

            sqlProvider.AddParameter("@OtobusId", instance.OtobusId);

            returnValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = returnValue != -1;

            return result;
        }

        // Sil

        public Result Delete(object instanceId)
        {
            Result result = new Result();

            int returnValue = 0;

            SqlProvider sqlProvider = new SqlProvider("Delete From Sefer Where SeferId=@Id", false);

            sqlProvider.AddParameter("@Id", instanceId);

            returnValue = sqlProvider.ExecuteNonQuery();

            result.IsSucceeded = returnValue != -1;

            return result;
        }
    }
}
